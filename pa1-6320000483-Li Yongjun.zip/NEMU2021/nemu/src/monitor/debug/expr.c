#include "nemu.h"

/* We use the POSIX regex functions to process regular expressions.
 * Type 'man regex' for more information about POSIX regex functions.
 */
#include <sys/types.h>
#include <regex.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "memory/memory.h"

enum {
	NOTYPE = 256, EQ, NUM, HEX, REG, NEQ, AND, NOT, DEREF

	/* TODO: Add more token types */

};

static struct rule {
	char *regex;
	int token_type;
} rules[] = {

	/* TODO: Add more rules.
	 * Pay attention to the precedence level of different rules.
	 */

	{" +",	NOTYPE},				// spaces
	{"\\+", '+'},					// plus
	{"\\-", '-'},
	{"\\*", '*'},
	{"/", '/'},
	{"==", EQ},					// equal
	{"!=", NEQ},                    
    {"&&", AND},                    
    {"!", NOT}, 
	{"0x[0-9a-fA-F]+" , HEX},
	{"[0-9]+", NUM},
	{"\\$[a-zA-Z]+", REG},     
	{"\\(", '('},              
	{"\\)", ')'},               
};

#define NR_REGEX (sizeof(rules) / sizeof(rules[0]) )

static regex_t re[NR_REGEX];

/* Rules are used for many times.
 * Therefore we compile them only once before any usage.
 */
void init_regex() {
	int i;
	char error_msg[128];
	int ret;

	for(i = 0; i < NR_REGEX; i ++) {
		ret = regcomp(&re[i], rules[i].regex, REG_EXTENDED);
		if(ret != 0) {
			regerror(ret, &re[i], error_msg, 128);
			Assert(ret == 0, "regex compilation failed: %s\n%s", error_msg, rules[i].regex);
		}
	}
}

typedef struct token {
	int type;
	char str[32];
} Token;

Token tokens[32];
int nr_token;

static bool make_token(char *e) {
	int position = 0;
	int i;
	regmatch_t pmatch;
	
	nr_token = 0;

	while(e[position] != '\0') {
		/* Try all rules one by one. */
		for(i = 0; i < NR_REGEX; i ++) {
			if(regexec(&re[i], e + position, 1, &pmatch, 0) == 0 && pmatch.rm_so == 0) {
				char *substr_start = e + position;
				int substr_len = pmatch.rm_eo;

				Log("match rules[%d] = \"%s\" at position %d with len %d: %.*s", i, rules[i].regex, position, substr_len, substr_len, substr_start);
				position += substr_len;

				/* TODO: Now a new token is recognized with rules[i]. Add codes
				 * to record the token in the array `tokens'. For certain types
				 * of tokens, some extra actions should be performed.
				 */

				if (rules[i].token_type != NOTYPE) {
					tokens[nr_token].type = rules[i].token_type;
					int copy_len = substr_len > 31 ? 31 : substr_len;
					strncpy(tokens[nr_token].str, substr_start, copy_len);
					tokens[nr_token].str[copy_len] = '\0';
					nr_token++;
				}
				break;
			}
		}


		if(i == NR_REGEX) {
			printf("no match at position %d\n%s\n%*.s^\n", position, e, position, "");
			return false;
		}
	}

	int j;
	for (j = 0; j < nr_token; j++) {
        if (tokens[j].type == '*') {
            if (j == 0 || (tokens[j-1].type != NUM && tokens[j-1].type != HEX &&
                           tokens[j-1].type != REG && tokens[j-1].type != ')')) {
                tokens[j].type = DEREF;
            }
        }
    }

	return true; 
}

bool check_parentheses(int p, int q) {
    if (tokens[p].type != '(' || tokens[q].type != ')') return false;
    int balance = 0;
	int i;
    for (i = p + 1; i < q; i++) {
        if (tokens[i].type == '(') balance++;
        else if (tokens[i].type == ')') balance--;
        if (balance < 0) return false;
    }
    return balance == 0;
}

int find_main_op(int p, int q) {
    int pos = -1, min_prec = 100, balance = 0;
	int i;
    for (i = p; i <= q; i++) {
        if (tokens[i].type == '(') balance++;
        else if (tokens[i].type == ')') balance--;
        else if (balance == 0) {
            int prec;
			if (tokens[i].type == AND) prec = 1;
            else if (tokens[i].type == EQ || tokens[i].type == NEQ) prec = 2;
            else if (tokens[i].type == '+' || tokens[i].type == '-') prec = 3;
            else if (tokens[i].type == '*' || tokens[i].type == '/') prec = 4;
            else continue;
            if (prec <= min_prec) { min_prec = prec; pos = i; }
        }
    }
    return pos;
}

uint32_t get_reg_value(const char *s, bool *success) {
    if (strcmp(s, "$eax") == 0) return cpu.gpr[0]._32;
    if (strcmp(s, "$ecx") == 0) return cpu.gpr[1]._32;
    if (strcmp(s, "$edx") == 0) return cpu.gpr[2]._32;
    if (strcmp(s, "$ebx") == 0) return cpu.gpr[3]._32;
    if (strcmp(s, "$esp") == 0) return cpu.gpr[4]._32;
    if (strcmp(s, "$ebp") == 0) return cpu.gpr[5]._32;
    if (strcmp(s, "$esi") == 0) return cpu.gpr[6]._32;
    if (strcmp(s, "$edi") == 0) return cpu.gpr[7]._32;
    if (strcmp(s, "$eip") == 0) return cpu.eip;
    *success = false;
    return 0;
}

uint32_t eval(int p, int q, bool *success) {
    if (p > q) { *success = false; return 0; }
    if (p == q) {
        if (tokens[p].type == NUM) return strtoul(tokens[p].str, NULL, 10);
        if (tokens[p].type == HEX) return strtoul(tokens[p].str, NULL, 16);
        if (tokens[p].type == REG) return get_reg_value(tokens[p].str, success);
        *success = false;
        return 0;
    }
    if (check_parentheses(p, q)) return eval(p + 1, q - 1, success);

	if (tokens[p].type == NOT) { 
        return !eval(p + 1, q, success);
    }

    if (tokens[p].type == DEREF) { 
        uint32_t addr = eval(p + 1, q, success);
        return swaddr_read(addr, 4);
    }

	int op = find_main_op(p, q);
    if (op == -1) { *success = false; return 0; }

    uint32_t val1 = eval(p, op - 1, success);
    uint32_t val2 = eval(op + 1, q, success);
    if (!*success) return 0;

    switch (tokens[op].type) {
        case '+': return val1 + val2;
        case '-': return val1 - val2;
        case '*': return val1 * val2;
        case '/': return val1 / val2;
        case EQ: return val1 == val2;
		case NEQ: return val1 != val2;  
        case AND: return val1 && val2;  
        default: *success = false; return 0;
    }
}


uint32_t expr(char *e, bool *success) {
	if(!make_token(e)) {
		*success = false;
		return 0;
	}
	return eval(0, nr_token -1, success); 
}


	/* TODO: Insert codes to evaluate the expression. */

