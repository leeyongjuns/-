#include "monitor/watchpoint.h"
#include "monitor/expr.h"
#include <stdio.h>
#include <string.h>

#define NR_WP 32

static WP wp_pool[NR_WP];
static WP *head = NULL;
static WP *free_ = NULL;

void init_wp_pool() {
	int i;
	for(i = 0; i < NR_WP; i ++) {
		wp_pool[i].NO = i;
		wp_pool[i].next = &wp_pool[i + 1];
	}
	wp_pool[NR_WP - 1].next = NULL;

	head = NULL;
	free_ = wp_pool;
}
WP* new_wp() {
	if(!free_) {
		printf("No free watchpoints available!\n ");
		return NULL;
	}

	WP *wp = free_;
	free_ = free_->next;

	wp->next = head;
	head = wp;

	return wp;
}

void free_wp(WP *wp) {
	WP **p = &head;
	while (*p && *p != wp) {
		p = &(*p)->next;
	}
	if (*p) {
        *p = wp->next;
        wp->next = free_;
        free_ = wp;
    }
}

void check_wp() {
    WP *p = head;
    while (p) {
        bool success = true;
        uint32_t new_val = expr(p->expr, &success);

        if (success && new_val != p->val) {
            printf("Watchpoint %d triggered: '%s' changed from %u to %u\n",
                   p->NO, p->expr, p->val, new_val);
            p->val = new_val;
        }
        p = p->next;
    }
}

WP* get_wp_head() {
    return head;  
}

WP* find_wp(int n) {
    WP *p = head;
    while (p != NULL) {
        if (p->NO == n) return p;
        p = p->next;
    }
    return NULL;
}

/* TODO: Implement the functionality of watchpoint */


