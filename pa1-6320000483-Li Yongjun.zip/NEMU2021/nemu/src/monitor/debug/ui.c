#include "monitor/monitor.h"
#include "monitor/expr.h"
#include "monitor/watchpoint.h"
#include "cpu/reg.h"
#include "memory/memory.h"
#include "nemu.h"

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <readline/readline.h>
#include <readline/history.h>

void cpu_exec(uint32_t);

/* We use the `readline' library to provide more flexibility to read from stdin. */
char* rl_gets() {
	static char *line_read = NULL;

	if (line_read) {
		free(line_read);
		line_read = NULL;
	}

	line_read = readline("(nemu) ");

	if (line_read && *line_read) {
		add_history(line_read);
	}

	return line_read;
}

static int cmd_c(char *args) {
	cpu_exec(-1);
	return 0;
}

static int cmd_q(char *args) {
	return -1;
}

static int cmd_help(char *args);

static int cmd_si(char *args) {
	int n = 1;
	if (args != NULL) sscanf(args, "%d",&n);
	if (n <= 0) n = 1;
	cpu_exec((uint64_t)n);
	return 0;
}

static int cmd_info (char *args) {
    if (args && args[0] == 'r') {
        int i;
        for (i = 0; i < 8; i++)   
            printf("%s\t0x%08x\t%d\n", regsl[i], reg_l(i), reg_l(i));
        printf("eip\t0x%08x\t%d\n", cpu.eip, cpu.eip);
    } 

    else if (args && args[0] == 'w') {
        WP *p = get_wp_head();
        while (p != NULL) {
            printf("Watchpoint %d: %s, current value = %u (0x%x)\n",
                   p->NO, p->expr, p->val, p->val);
            p = p->next;
        }
    }
    else { 
        printf("Usage: info r | info w\n");
    }
    return 0;
}

static int cmd_x(char *args) {
	if (!args) { printf("Usage: x N ADDR\n"); return 0; }
	int n; unsigned addr;
	if (sscanf(args, "%d %x", &n, &addr) != 2) {
		printf("Usage: x N ADDR\n");
		return 0;
	}
	int i;
	for (i = 0; i < n; i++) {
		uint32_t data = swaddr_read(addr + i * 4, 4);
		printf("0x%08x: 0x%08x\n", addr + i * 4, data);
	}
	return 0;
}

static int cmd_p(char *args)
{
	if (args == NULL) {
		printf("Usage: p EXPR\n");
		return 0;
	}
	bool success = true;
	uint32_t val = expr(args, &success);
	if (success) {
		printf("%u (0x%x)\n", val, val);
	} else {
		printf("Invalid expresion.\n");
	}
	return 0;
}
static int cmd_w(char *args) {
	if (args == NULL) {
		printf("Usage: w EXPR\n");
		return 0;
	}
	WP *wp = new_wp();
	strncpy(wp->expr, args, sizeof(wp->expr) - 1);
	wp->expr[sizeof(wp->expr) - 1] = '\0';

	bool success = true;
	wp->val = expr(args, &success);
	if(success) {
		printf("Watchpoint %d set on '%s', initial value: %u (0x%x)\n", wp->NO, wp->expr, wp->val, wp->val);
    } else {
		printf("Invalid expression\n");
	}
	return 0;
}

static int cmd_d(char *args) {
    if (args == NULL) {
        printf("Usage: d N\n");
        return 0;
    }
    int n;
    if (sscanf(args, "%d", &n) != 1) {
        printf("Usage: d N\n");
        return 0;
    }
    WP *p = find_wp(n);
    if (p) {
        free_wp(p);
        printf("Deleted watchpoint %d\n", n);
    } else {
        printf("No watchpoint number %d\n", n);
    }
    return 0;
}


static struct {
	char *name;
	char *description;
	int (*handler) (char *);
} cmd_table [] = {
	{ "help", "Display informations about all supported commands", cmd_help },
	{ "c", "Continue the execution of the program", cmd_c },
	{ "q", "Exit NEMU", cmd_q },

	/* TODO: Add more commands */

	{ "si", "Step by step execution", cmd_si },
	{ "info", "Print register status or watchpoints", cmd_info },
	{ "x", "Scan memory", cmd_x },
	{ "p", "Calculate expression", cmd_p },
	{ "w", "Set a watchpoint", cmd_w },
	{ "d", "Delete a watchpoint", cmd_d }
};

#define NR_CMD (sizeof(cmd_table) / sizeof(cmd_table[0]))

static int cmd_help(char *args) {
	/* extract the first argument */
	char *arg = strtok(NULL, " ");
	int i;

	if(arg == NULL) {
		/* no argument given */
		for(i = 0; i < NR_CMD; i ++) {
			printf("%s - %s\n", cmd_table[i].name, cmd_table[i].description);
		}
	}
	else {
		for(i = 0; i < NR_CMD; i ++) {
			if(strcmp(arg, cmd_table[i].name) == 0) {
				printf("%s - %s\n", cmd_table[i].name, cmd_table[i].description);
				return 0;
			}
		}
		printf("Unknown command '%s'\n", arg);
	}
	return 0;
}

void ui_mainloop() {
	while(1) {
		char *str = rl_gets();
		char *str_end = str + strlen(str);

		/* extract the first token as the command */
		char *cmd = strtok(str, " ");
		if(cmd == NULL) { continue; }

		/* treat the remaining string as the arguments,
		 * which may need further parsing
		 */
		char *args = cmd + strlen(cmd) + 1;
		if(args >= str_end) {
			args = NULL;
		}

#ifdef HAS_DEVICE
		extern void sdl_clear_event_queue(void);
		sdl_clear_event_queue();
#endif

		int i;
		for(i = 0; i < NR_CMD; i ++) {
			if(strcmp(cmd, cmd_table[i].name) == 0) {
				if(cmd_table[i].handler(args) < 0) { return; }
				break;
			}
		}

		if(i == NR_CMD) { printf("Unknown command '%s'\n", cmd); }
	}
}
