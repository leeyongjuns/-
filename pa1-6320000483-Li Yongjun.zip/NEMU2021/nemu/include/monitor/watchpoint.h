#ifndef __WATCHPOINT_H__
#define __WATCHPOINT_H__

#include "common.h"

typedef struct watchpoint {
	int NO;
	struct watchpoint *next;
	char expr[256];
	uint32_t val;


	/* TODO: Add more members if necessary */


} WP;

WP* new_wp();
void free_wp(WP *wp);
void check_wp();
void init_wp_pool();

WP* get_wp_head();   
WP* find_wp(int n);


#endif

